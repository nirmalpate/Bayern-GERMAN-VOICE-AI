from fastapi import FastAPI, Request, Form
from fastapi.responses import Response
from fastapi.concurrency import run_in_threadpool
from app.agent import HotelAgent

app = FastAPI(title="Hotel Bayerischer Hof Voice Agent")
SESSIONS = {}

@app.get("/health")
def health_check():
    return {"status": "healthy", "hotel": "Bayerischer Hof München", "architecture": "Context Injection"}

@app.post("/voice")
async def handle_incoming_call(request: Request, From: str = Form(...), CallSid: str = Form(...)):
    agent = HotelAgent(call_id=CallSid, caller_number=From)
    SESSIONS[CallSid] = agent

    if agent.is_night_shift:
        greeting = "Guten Abend beim Nachtservice des Hotel Bayerischer Hof in München. Haben Sie ein dringendes Anliegen oder einen Notfall?"
    else:
        greeting = "Grüß Gott und herzlich willkommen im Hotel Bayerischer Hof in München. Wie kann ich Ihnen heute behilflich sein?"

    twiml_response = f"""<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Gather input="speech" action="/respond" method="POST" language="de-DE" speechTimeout="auto">
        <Say language="de-DE">{greeting}</Say>
    </Gather>
</Response>
"""
    return Response(content=twiml_response, media_type="application/xml")

@app.post("/respond")
async def handle_response(CallSid: str = Form(...), SpeechResult: str = Form(...)):
    agent = SESSIONS.get(CallSid)
    if not agent:
        agent = HotelAgent(call_id=CallSid)
        SESSIONS[CallSid] = agent

    reply_text = await run_in_threadpool(agent.reply, SpeechResult)

    twiml_response = f"""<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Gather input="speech" action="/respond" method="POST" language="de-DE" speechTimeout="auto">
        <Say language="de-DE">{reply_text}</Say>
    </Gather>
</Response>
"""
    return Response(content=twiml_response, media_type="application/xml")
